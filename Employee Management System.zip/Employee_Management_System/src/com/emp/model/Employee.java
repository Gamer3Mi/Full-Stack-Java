package com.emp.model;

public class Employee {

	private int eid;
	private String ename,email,addr,gender,phone,aadhar;
	private double salary;

	public Employee(int eid,String ename,String email,String addr,String gender,String phone,String aadhar,double salary)
	{
		this.eid=eid;
		this.ename=ename;
		this.email=email;
		this.addr=addr;
		this.gender=gender;
		this.phone=phone;
		this.aadhar=aadhar;
		this.salary=salary;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAadhar() {
		return aadhar;
	}

	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
}
