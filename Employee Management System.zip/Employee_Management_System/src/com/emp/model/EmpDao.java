package com.emp.model;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EmpDao {

	Connection con;
	PreparedStatement stmt;
	String url="jdbc:mysql://localhost:3306/employee",username="root",pass="gamer3mi";
	
	public EmpDao() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection(url, username, pass);
	}
	
	public boolean validate(String uname,String pass) throws SQLException
	{
		String q = "select * from login where username=? and password=?";
		stmt = con.prepareStatement(q);
		stmt.setString(1, uname);
		stmt.setString(2, pass);
		ResultSet rs = stmt.executeQuery();
		
		if(rs.next())
			return true;
		else
			return false;
	}
	
	public boolean insert(Employee emp) throws SQLException
	{
		String q = "insert into employee values(?,?,?,?,?,?,?,?)";
		stmt = con.prepareStatement(q);
		stmt.setInt(1, emp.getEid());
		stmt.setString(2, emp.getEname());
		stmt.setString(3, emp.getEmail());
		stmt.setString(4, emp.getAddr());
		stmt.setString(5, emp.getGender());
		stmt.setString(6, emp.getPhone());
		stmt.setString(7, emp.getAadhar());
		stmt.setDouble(8, emp.getSalary());
		
		int r = stmt.executeUpdate();
		
		if(r>0)
			return true;
		else
			return false;
		
	}
	
	public ResultSet getIDs() throws SQLException
	{
		String q ="select * from Employee";
		stmt = con.prepareStatement(q);
		
		ResultSet rs = stmt.executeQuery();
		return rs;
	}
	
	public ResultSet searchEmp(int id) throws SQLException
	{
		String q ="select * from Employee where eid = ?";
		stmt = con.prepareStatement(q);
		stmt.setInt(1, id);
		ResultSet rs = stmt.executeQuery();
		return rs;
	}
	
	public boolean updateEmp(Employee emp) throws SQLException
	{
		String q = "update Employee set ename=?, email=?,addr=?,phone=?,salary=? where eid=?";
		stmt = con.prepareStatement(q);
		stmt.setString(1, emp.getEname());
		stmt.setString(2, emp.getEmail());
		stmt.setString(3, emp.getAddr());
		stmt.setString(4, emp.getPhone());
		stmt.setDouble(5, emp.getSalary());
		stmt.setInt(6, emp.getEid());
		int r = stmt.executeUpdate();
		if(r>0)
			return true;
		else
			return false;
	}
	
	public boolean deleteEmp(int id) throws SQLException
	{
		String q = "delete from Employee where eid=?";
		stmt=con.prepareStatement(q);
		stmt.setInt(1, id);
		
		int r = stmt.executeUpdate();
		if(r>0)
			return true;
		else
			return false;
		
	}
	
	
}
