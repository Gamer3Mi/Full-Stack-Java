package com.emp.client;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class DashBoard extends JFrame {
	
	JButton add,remove,view,logout;
	
	public DashBoard(String t)
	{
		
		super(t);
		
		JLabel heading = new JLabel("Employee Management System");
		heading.setFont(new Font("Arial Black",Font.BOLD,38));
		heading.setForeground(Color.white);
		heading.setBounds(250, 50, 700, 50);
		add(heading);
		
		add = new JButton("Add Employee");
		add.setForeground(Color.black);
		add.setBounds(470,155,230,70);
		add.setFont(new Font("Arial",Font.BOLD,20));
		add.setBackground(new Color(171,219,227));
		add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
				new AddEmp("Add Employee");
				
			}
		});
		add(add);
		
		remove = new JButton("Remove Employee");
		remove.setForeground(Color.black);
		remove.setBounds(470,270,230,70);
		remove.setFont(new Font("Arial",Font.BOLD,20));
		remove.setBackground(new Color(171,219,227));
		remove.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new DeleteEmp();
			}
		});
		add(remove);
		
		view = new JButton("View Employee");
		view.setForeground(Color.black);
		view.setBounds(470,390,230,70);
		view.setFont(new Font("Arial",Font.BOLD,20));
		view.setBackground(new Color(171,219,227));
		view.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new ViewEmp("Edit & View Employee");
			}
		});
		add(view);
		
		logout= new JButton("Log Out");
		logout.setForeground(Color.black);
		logout.setBounds(470,510,230,70);
		logout.setFont(new Font("Arial",Font.BOLD,20));
		logout.setBackground(new Color(171,219,227));
		logout.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new Login("Login");
			}
		});
		
		add(logout);
		
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("./images/dashboard.jpeg"));
		Image i2 = i1.getImage().getScaledInstance(1170,650, Image.SCALE_DEFAULT);
		ImageIcon i3 = new ImageIcon(i2);
		JLabel image = new JLabel(i3);
		image.setBounds(0,0,1170,650);
		add(image);
		
		setSize(1170,650);
		setVisible(true);
		setLocation(100,50);
		setLayout(null);
		setResizable(false);
		
	}

	public static void main(String[] args) {
		new DashBoard("Homepage");
	}
}
