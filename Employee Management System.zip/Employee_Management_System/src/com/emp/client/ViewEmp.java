package com.emp.client;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.emp.model.EmpDao;

import net.proteanit.sql.DbUtils;

public class ViewEmp extends JFrame implements ActionListener {

	Choice choice;
	EmpDao dao;
	JTable table;
	JButton search,print,update,back;
	
	public ViewEmp(String t)
	{
		super(t);
		setLayout(null);
		getContentPane().setBackground(Color.white);
		
		JLabel l1 = new JLabel("Search Employee : ");
		l1.setBounds(140,47,200,50);
		l1.setForeground(Color.black);
		l1.setFont(new Font("Arial",Font.BOLD,20));
		add(l1);
		
		
		choice = new Choice();
		choice.setBounds(350,62,300,30);
		add(choice);
		try {
			dao = new EmpDao();
			ResultSet rs = dao.getIDs();
			while(rs.next())
			{
				choice.add(rs.getString("eid"));
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		table= new JTable();
		try {
			dao = new EmpDao();
			ResultSet rs = dao.getIDs();
			table.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		JScrollPane pane = new JScrollPane(table);
		pane.setBounds(17,200,900,500);
		add(pane);
		
		search = new JButton("Search");
		search.setBounds(680,60,100,25);
		search.setBackground(Color.black);
		search.setFont(new Font("Arial",Font.BOLD,15));
		search.setForeground(Color.white);
		search.addActionListener(this);
		add(search);
		
		print= new JButton("Print");
		print.setBounds(160,120,100,40);
		print.setBackground(Color.black);
		print.setFont(new Font("Arial",Font.BOLD,15));
		print.setForeground(Color.white);
		print.addActionListener(this);
		add(print);
		
		update= new JButton("Update");
		update.setBounds(420,120,100,40);
		update.setBackground(Color.black);
		update.setFont(new Font("Arial",Font.BOLD,15));
		update.setForeground(Color.white);
		update.addActionListener(this);
		add(update);
		
		back= new JButton("Back");
		back.setBounds(670,120,100,40);
		back.setBackground(Color.black);
		back.setFont(new Font("Arial",Font.BOLD,15));
		back.setForeground(Color.white);
		back.addActionListener(this);
		add(back);
		
		setSize(950,750);
		setLocation(200,0);
		setResizable(false);
		setVisible(true);
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==search)
		{
			try {
				dao = new EmpDao();
				ResultSet rs = dao.searchEmp(Integer.parseInt(choice.getSelectedItem()));
				table.setModel(DbUtils.resultSetToTableModel(rs));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		else if(e.getSource()==back)
		{
			setVisible(false);
			new DashBoard("Homepage");
		}
		else if(e.getSource()==print)
		{
			try {
				table.print();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		else if(e.getSource()==update){
			setVisible(false);
			new UpdateEmployee(Integer.parseInt(choice.getSelectedItem()));
		}
		
	}

	public static void main(String[] args) {
		
		new ViewEmp("Edit & View Employee");
		
	}
}
