package com.emp.client;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.emp.model.EmpDao;

public class DeleteEmp extends JFrame implements ActionListener  {
	
	JTextField tf;
	JButton delete,back;
	EmpDao dao;
	
	DeleteEmp()
	{
		
		setTitle("Delete");
		getContentPane().setBackground(Color.black);
		
		
		JLabel heading = new JLabel("Enter ID to Delete ");
		heading.setBounds(65, 45, 200, 50);;
		heading.setFont(new Font("Arial",Font.BOLD,20));
		heading.setForeground(Color.white);
		add(heading);
		
		tf = new JTextField();
		tf.setBounds(65, 110, 250, 30);;
		tf.setFont(new Font("Arial",Font.BOLD,16));
		
		tf.setForeground(Color.black);
		add(tf);
		
		delete = new JButton("Delete");
		delete.setBounds(65,180,100,40);
		delete.setBackground(new Color(100, 216, 205));
		delete.setForeground(Color.black);
		delete.setFont(new Font("Arial",Font.BOLD,20));
		delete.addActionListener(this);
		add(delete);
		
		back = new JButton("Back");
		back.setBounds(215,180,100,40);
		back.setBackground(new Color(222, 146, 208));
		back.setForeground(Color.black);
		back.setFont(new Font("Arial",Font.BOLD,20));
		back.addActionListener(this);
		add(back);
		
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("./images/Delete.jpeg"));
		Image i2 = i1.getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT);
		ImageIcon i3 = new ImageIcon(i2);
		JLabel image = new JLabel(i3);
		image.setBounds(330, 30, 300, 200);
		add(image);
	
		
		setResizable(false);
		setLocation(400,250);
		setLayout(null);
		setSize(600,300);
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==delete)
		{
			int eid =Integer.parseInt(tf.getText());
			try {
				dao = new EmpDao();
				boolean r=dao.deleteEmp(eid);
				if(r)
				{
					JOptionPane.showMessageDialog(null, "Record Vanished..");
					setVisible(false);
					new ViewEmp("View & Edit Employee");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Record Not Found..");
					setVisible(false);
					new ViewEmp("View & Edit Employee");
				}
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			
		}else if(e.getSource()==back)
		{
			setVisible(false);
			new ViewEmp("View & Edit Employee");
		}
		
	}

	public static void main(String[] args) {
		
		new DeleteEmp();
	}


}
