package com.emp.client;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import com.emp.model.EmpDao;
import com.emp.model.Employee;

public class AddEmp extends JFrame implements ActionListener {
	
	private JLabel lid,lname,laddress,lgender,laadhar,lemail,lphone,lsalary;
	private JTextField id,name,address,aadhar,email,phone,salary;
	private JRadioButton male,female;
	private ButtonGroup gender;
	private JButton add,reset,backtohome;
	private Employee emp;
	private EmpDao dao;
	

	AddEmp(String t)
	{
		super(t);
		
		getContentPane().setBackground(new Color(211,211,211));
		
		JLabel heading = new JLabel("Add Employee Details");
		heading.setForeground(Color.blue);
		heading.setFont(new Font("Arial", Font.BOLD, 26));
		heading.setBounds(215,30,280,35);
		add(heading);
		
		lid= new JLabel("Enter Id : ");
		lid.setBounds(130, 90, 100,50);
		lid.setFont(new Font("Calibri",Font.BOLD,20));
		lid.setForeground(Color.black);
		add(lid);
		
		id = new JTextField();
		id.setBounds(340, 100, 240,30);
		id.setBackground(Color.black);
		id.setFont(new Font("Calibri",Font.BOLD,16));
		id.setForeground(Color.white);
		add(id);
		
		lname= new JLabel("Enter Name : ");
		lname.setBounds(130, 140, 130,50);
		lname.setFont(new Font("Calibri",Font.BOLD,20));
		lname.setForeground(Color.black);
		add(lname);
		
		name = new JTextField();
		name.setBackground(Color.black);
		name.setBounds(340, 150, 240,30);
		name.setFont(new Font("Calibri",Font.BOLD,16));
		name.setForeground(Color.white);
		add(name);
		
		laddress = new JLabel("Enter Address :");
		laddress.setBounds(130,200,150,50);
		laddress.setFont(new Font("Calibri",Font.BOLD,20));
		laddress.setForeground(Color.black);
		add(laddress);
		
		address = new JTextField();
		address.setBackground(Color.black);
		address.setBounds(340, 210, 240,30);
		address.setFont(new Font("Calibri",Font.BOLD,16));
		address.setForeground(Color.white);
		add(address);
		
		lgender = new JLabel("Select Gender :");
		lgender.setBounds(130,255,150,50);
		lgender.setFont(new Font("Calibri",Font.BOLD,20));
		lgender.setForeground(Color.black);
		add(lgender);
		
		male = new JRadioButton("Male");
		male.setBounds(340,270,80,30);
		male.setBackground(new Color(211,211,211));
		male.setFont(new Font("Calibri",Font.BOLD,17));
		male.setForeground(Color.black);
		add(male);
		
		female = new JRadioButton("Female");
		female.setBounds(490,270,80,30);
		female.setBackground(new Color(211,211,211));
		female.setFont(new Font("Calibri",Font.BOLD,17));
		female.setForeground(Color.black);
		add(female);
		
		gender= new ButtonGroup();
		gender.add(male);
		gender.add(female);
		
		laadhar = new JLabel("Enter Aadhar :");
		laadhar.setBounds(130,315,150,50);
		laadhar.setFont(new Font("Calibri",Font.BOLD,20));
		laadhar.setForeground(Color.black);
		add(laadhar);
		
		aadhar = new JTextField();
		aadhar.setBackground(Color.black);
		aadhar.setBounds(340, 325, 240,30);
		aadhar.setFont(new Font("Calibri",Font.BOLD,16));
		aadhar.setForeground(Color.white);
		add(aadhar);
		
		lemail = new JLabel("Enter Email :");
		lemail.setBounds(130,380,150,50);
		lemail.setFont(new Font("Calibri",Font.BOLD,20));
		lemail.setForeground(Color.black);
		add(lemail);
		
		email = new JTextField();
		email.setBackground(Color.black);
		email.setBounds(340, 385, 240,30);
		email.setFont(new Font("Calibri",Font.BOLD,17));
		email.setForeground(Color.white);
		add(email);
		
		lphone = new JLabel("Enter Phone :");
		lphone.setBounds(130,440,150,50);
		lphone.setFont(new Font("Calibri",Font.BOLD,20));
		lphone.setForeground(Color.black);
		add(lphone);
		
		phone = new JTextField();
		phone.setBackground(Color.black);
		phone.setBounds(340, 445, 240,30);
		phone.setFont(new Font("Calibri",Font.BOLD,17));
		phone.setForeground(Color.white);
		add(phone);
		
		lsalary = new JLabel("Enter Salary :");
		lsalary.setBounds(130,500,150,50);
		lsalary.setFont(new Font("Calibri",Font.BOLD,20));
		lsalary.setForeground(Color.black);
		add(lsalary);
		
		salary = new JTextField();
		salary.setBackground(Color.black);
		salary.setBounds(340, 505, 240,30);
		salary.setFont(new Font("Calibri",Font.BOLD,17));
		salary.setForeground(Color.white);
		add(salary);
		
		add = new JButton("Add");
		add.setBounds(170, 570, 130, 40);
		add.setFont(new Font("Arial Bold",Font.BOLD,15));
		add.setBackground(Color.blue);
		add.setForeground(Color.white);
		add.addActionListener(this);
		add(add);
		
		reset = new JButton("Reset");
		reset.setBounds(400, 570, 130, 40);
		reset.setFont(new Font("Arial Bold",Font.BOLD,15));
		reset.setBackground(Color.red);
		reset.setForeground(Color.white);
		reset.addActionListener(this);
		add(reset);
		
		backtohome = new JButton("Back To Home");
		backtohome.setBounds(170, 630, 360, 50);
		backtohome.setFont(new Font("Arial Bold",Font.BOLD,15));
		backtohome.setBackground(new Color(0, 163, 108));
		backtohome.setForeground(Color.white);
		add(backtohome);
		backtohome.addActionListener(this);
		
		setLayout(null);
		setVisible(true);
		setLocation(330,0);
		setSize(700,750);
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==add)
		{
			int eid =Integer.parseInt(id.getText());
			String ename=name.getText();
			String addr = address.getText();
			String eaadhar = aadhar.getText();
			String eemail = email.getText();
			String ephone = phone.getText();
			double sal = Double.parseDouble(salary.getText());
			String egender;
			if(male.isSelected())
				egender="Male";
			else
				egender="Female";
			
			emp = new Employee(eid, ename, eemail, addr, egender, ephone, eaadhar, sal);
			
			try {
				dao = new EmpDao();
				boolean r = dao.insert(emp);
				if(r)
				{
					JOptionPane.showMessageDialog(null, "Record Inserted Successfully..");
					setVisible(false);
					new DashBoard("Homepage");
				}
				
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}else if(e.getSource()==reset)
		{
			id.setText("");
			name.setText("");
			address.setText("");
			aadhar.setText("");
			email.setText("");
			phone.setText("");
			salary.setText("");
			gender.clearSelection();
		}else if(e.getSource()==backtohome)
		{
			setVisible(false);
			new DashBoard("DashBoard");
		}
		
	}
	
	public static void main(String[] args) {
		new AddEmp("AddEmp");
	}

}
