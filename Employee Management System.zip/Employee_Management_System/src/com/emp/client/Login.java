package com.emp.client;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.Border;

import com.emp.model.EmpDao;

public class Login extends JFrame implements ActionListener{
	
	JTextField uname,pass;
	JButton login,back;
	EmpDao dao;
	
	public Login(String title) {
		super(title);
		
		JLabel username = new JLabel("Username");
		username.setFont(new Font("Arial Bold",Font.BOLD,15));;
		username.setBounds(60,30,100,50);
		username.setForeground(Color.white);
		add(username);
		
		JLabel password = new JLabel("Password");
		password.setFont(new Font("Arial Bold",Font.BOLD,15));
		password.setBounds(60,100,100,50);
		password.setForeground(Color.white);
		add(password);
		
		uname = new JTextField();
		uname.setBounds(160,43,180,30);
		uname.setFont(new Font("Arial Bold",Font.BOLD,17));
		add(uname);
		
		pass = new JPasswordField();
		pass.setBounds(160,110,180,30);
		pass.setFont(new Font("Arial Bold",Font.BOLD,17));
		add(pass);
		
		login= new JButton("LOGIN");
		login.setBounds(110,180,150,40);
		login.setFont(new Font("Arial Bold",Font.BOLD,15));
		login.setBackground(Color.black);
		login.setForeground(Color.white);
		login.addActionListener(this);
		add(login);
		
		back= new JButton("BACK");
		back.setBounds(320,180,150,40);
		back.setFont(new Font("Arial Bold",Font.BOLD,15));
		back.setBackground(Color.black);
		back.setForeground(Color.white);
		back.addActionListener(this);
		add(back);
		
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("./images/login.jpeg"));
		Image i2 = i1.getImage().getScaledInstance(600,300, Image.SCALE_DEFAULT);
		ImageIcon i3 = new ImageIcon(i2);
		JLabel img = new JLabel(i3);
		img.setBounds(0,0,600,300);
		add(img);
		
		
		
		setResizable(false);
		setLocation(400,250);
		setLayout(null);
		setSize(600,300);
		setVisible(true);
		
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==login)
		{
			String u = uname.getText();
			String p = pass.getText();
			
			try {
				dao = new EmpDao();
				boolean r = dao.validate(u, p);
				if(r)
				{
					setVisible(false);
					new DashBoard("Homepage");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Invalid Username or Password");
				}
			} catch (SQLException | ClassNotFoundException e1) {
				e1.printStackTrace();
			}
			
			
		}
		else if(e.getSource()==back)
		{
			System.exit(50);
		}
		
	}
	
	public static void main(String[] args) {
		new Login("Login");
	}

}
