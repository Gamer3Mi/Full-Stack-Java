package com.emp.client;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import com.emp.model.EmpDao;
import com.emp.model.Employee;

public class UpdateEmployee extends JFrame implements ActionListener {
	
	private JLabel lid,id,lname,laddress,aadhar,laadhar,lemail,lphone,lsalary;
	private JTextField name,address,email,phone,salary;
	private JButton update,back;
	private int empid;
	private EmpDao dao;
	
	public UpdateEmployee(int empid)
	{
		this.empid=empid;
		
		getContentPane().setBackground(new Color(211,211,211));
		
		JLabel heading = new JLabel("Update Details");
		heading.setForeground(Color.blue);
		heading.setFont(new Font("Arial", Font.BOLD, 26));
		heading.setBounds(250,30,280,35);
		add(heading);
		
		lid= new JLabel("Enter Id : ");
		lid.setBounds(130, 90, 100,50);
		lid.setFont(new Font("Calibri",Font.BOLD,20));
		lid.setForeground(Color.black);
		add(lid);
		
		id = new JLabel();
		id.setBounds(340, 100, 240,30);
		id.setBackground(Color.gray);
		id.setFont(new Font("Calibri",Font.BOLD,16));
		id.setForeground(Color.RED);
		add(id);
		
		lname= new JLabel("Enter Name : ");
		lname.setBounds(130, 140, 130,50);
		lname.setFont(new Font("Calibri",Font.BOLD,20));
		lname.setForeground(Color.black);
		add(lname);
		
		name = new JTextField();
		name.setBackground(Color.black);
		name.setBounds(340, 150, 240,30);
		name.setFont(new Font("Calibri",Font.BOLD,16));
		name.setForeground(Color.white);
		add(name);
		
		laddress = new JLabel("Enter Address :");
		laddress.setBounds(130,200,150,50);
		laddress.setFont(new Font("Calibri",Font.BOLD,20));
		laddress.setForeground(Color.black);
		add(laddress);
		
		address = new JTextField();
		address.setBackground(Color.black);
		address.setBounds(340, 210, 240,30);
		address.setFont(new Font("Calibri",Font.BOLD,16));
		address.setForeground(Color.white);
		add(address);
		
		laadhar = new JLabel("Enter Aadhar :");
		laadhar.setBounds(130,315,150,50);
		laadhar.setFont(new Font("Calibri",Font.BOLD,20));
		laadhar.setForeground(Color.black);
		add(laadhar);
		
		aadhar = new JLabel();
		aadhar.setBackground(Color.gray);
		aadhar.setBounds(340, 325, 240,30);
		aadhar.setFont(new Font("Calibri",Font.BOLD,16));
		aadhar.setForeground(Color.RED);
		add(aadhar);
		
		lemail = new JLabel("Enter Email :");
		lemail.setBounds(130,380,150,50);
		lemail.setFont(new Font("Calibri",Font.BOLD,20));
		lemail.setForeground(Color.black);
		add(lemail);
		
		email = new JTextField();
		email.setBackground(Color.black);
		email.setBounds(340, 385, 240,30);
		email.setFont(new Font("Calibri",Font.BOLD,17));
		email.setForeground(Color.white);
		add(email);
		
		lphone = new JLabel("Enter Phone :");
		lphone.setBounds(130,440,150,50);
		lphone.setFont(new Font("Calibri",Font.BOLD,20));
		lphone.setForeground(Color.black);
		add(lphone);
		
		phone = new JTextField();
		phone.setBackground(Color.black);
		phone.setBounds(340, 445, 240,30);
		phone.setFont(new Font("Calibri",Font.BOLD,17));
		phone.setForeground(Color.white);
		add(phone);
		
		lsalary = new JLabel("Enter Salary :");
		lsalary.setBounds(130,500,150,50);
		lsalary.setFont(new Font("Calibri",Font.BOLD,20));
		lsalary.setForeground(Color.black);
		add(lsalary);
		
		salary = new JTextField();
		salary.setBackground(Color.black);
		salary.setBounds(340, 505, 240,30);
		salary.setFont(new Font("Calibri",Font.BOLD,17));
		salary.setForeground(Color.white);
		add(salary);
		
		try {
			dao = new EmpDao();
			ResultSet rs =dao.searchEmp(empid);
			while(rs.next())
			{
				id.setText(""+rs.getInt(1));
				name.setText(rs.getString(2));
				address.setText(rs.getString(4));
				aadhar.setText(rs.getString(7));
				email.setText(rs.getString(3));
				phone.setText(rs.getString(6));
				salary.setText(rs.getString(8));
			}			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		update = new JButton("Update");
		update.setBounds(170, 570, 130, 40);
		update.setFont(new Font("Arial Bold",Font.BOLD,15));
		update.setBackground(Color.blue);
		update.setForeground(Color.white);
		update.addActionListener(this);
		add(update);
		
		back = new JButton("Back");
		back.setBounds(400, 570, 130, 40);
		back.setFont(new Font("Arial Bold",Font.BOLD,15));
		back.setBackground(Color.red);
		back.setForeground(Color.white);
		back.addActionListener(this);
		add(back);
		
		setLayout(null);
		setVisible(true);
		setLocation(330,0);
		setSize(700,700);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==update)
		{
			int eid =Integer.parseInt( id.getText());
			String ename = name.getText();
			String eemail = email.getText();
			String addre = address.getText();
			String gen = null;
			String p = phone.getText();
			String aadh = aadhar.getText();
			double sal = Double.parseDouble(salary.getText());
			
			Employee emp = new Employee(eid, ename, eemail, addre, gen, p, aadh, sal);
			
			try {
				dao=new EmpDao();
				boolean r = dao.updateEmp(emp);
				if(r)
				{
					JOptionPane.showMessageDialog(null, "Record Succesfully Updated..");
					setVisible(false);
					new ViewEmp("Edit & View Employee");					
				}
				else
					JOptionPane.showMessageDialog(null, "Something went Wrong..");
			} catch (Exception e1) {
				
				e1.printStackTrace();
			} 
		}else if(e.getSource()==back)
		{
			setVisible(false);
			new ViewEmp("View & Edit Employee");
		}
			
	}
		
	      
	public static void main(String[] args) {
		
		new UpdateEmployee(4);
	}




}
